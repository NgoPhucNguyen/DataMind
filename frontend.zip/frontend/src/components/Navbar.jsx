import { useNavigate, useLocation } from "react-router-dom";

export default function Navbar() {
    const navigate = useNavigate();
    const location = useLocation();

    return (
        <header className="border-b border-white/10 px-6 py-4 flex justify-between items-center bg-[#0B0F1A] sticky top-0 z-50">
            {/* Logo */}
            <span
                className="text-lg font-bold tracking-tight cursor-pointer select-none"
                onClick={() => navigate("/home")}
            >
                DataMind<span className="text-violet-400">.</span>
            </span>

            {/* Nav links */}
            <nav className="flex items-center gap-1">
                <button
                    onClick={() => navigate("/home")}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                        location.pathname === "/home"
                            ? "bg-violet-500/20 text-violet-400"
                            : "text-white/50 hover:text-white hover:bg-white/5"
                    }`}
                >
                    Home
                </button>
                <button
                    onClick={() => navigate("/login")}
                    className="text-sm text-white/50 hover:text-white transition-colors px-4 py-2 rounded-lg hover:bg-white/5 font-medium"
                >
                    Đăng nhập
                </button>
                <button
                    onClick={() => navigate("/register")}
                    className="text-sm bg-violet-500 hover:bg-violet-400 text-white px-4 py-2 rounded-lg font-semibold transition-all"
                >
                    Đăng ký
                </button>
            </nav>
        </header>
    );
}
